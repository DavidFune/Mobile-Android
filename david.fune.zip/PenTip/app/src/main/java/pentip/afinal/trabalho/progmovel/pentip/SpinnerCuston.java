package pentip.afinal.trabalho.progmovel.pentip;

import android.app.Activity;

public class SpinnerCuston extends Activity {
}
